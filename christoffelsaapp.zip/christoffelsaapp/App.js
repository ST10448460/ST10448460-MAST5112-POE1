import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import {
  View,
  Text,
  TextInput,
  Button,
  FlatList,
  StyleSheet,
  Image,
  TouchableOpacity,
} from "react-native";

const Stack = createStackNavigator();


const initialMenu = [
  {
    name: "Caesar Salad",
    price: 130,
    course: "Starter",
    image: "https://natashaskitchen.com/wp-content/uploads/2019/01/Caesar-Salad-Recipe-3-600x900.jpg",
  },
  {
    name: "Grilled Chicken",
    price: 125,
    course: "Main",
    image: "https://hips.hearstapps.com/hmg-prod/images/grilled-chicken-breast-lead-6626cdb0bb5ac.jpg?crop=1xw:1xh;center,top&resize=1200:*",
  },
  {
    name: "Cheesecake",
    price: 130,
    course: "Dessert",
    image: "https://sallysbakingaddiction.com/wp-content/uploads/2019/03/no-bake-cheesecake-4.jpg",
  },
  {
    name: "Tomato Soup",
    price: 100,
    course: "Starter",
    image: "https://natashaskitchen.com/wp-content/uploads/2021/08/Tomato-Soup-Recipe-4-728x1092.jpg",
  },
];

const HomeScreen = ({ navigation, route }) => {
  const [menu, setMenu] = useState(route.params?.menu || initialMenu);

  const calculateAveragePrice = () => {
    if (menu.length === 0) return 0;
    const total = menu.reduce((sum, item) => sum + item.price, 0);
    return (total / menu.length).toFixed(2);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Home Screen</Text>
      <Text>Average Price: R{calculateAveragePrice()}</Text>
      <FlatList
        data={menu}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.item}>
              {item.course}: {item.name} - R{item.price}
            </Text>
          </View>
        )}
      />
      <Button
        title="Manage Menu"
        onPress={() =>
          navigation.navigate("ManageMenu", { menu, setMenu })
        }
      />
      <Button
        title="Filter Menu"
        onPress={() => navigation.navigate("FilterMenu", { menu })}
      />
    </View>
  );
};

const ManageMenuScreen = ({ route, navigation }) => {
  const [menu, setMenu] = useState(route.params.menu || []);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [course, setCourse] = useState("");
  const [image, setImage] = useState("");

  const addMenuItem = () => {
    if (name && price && course && image) {
      setMenu([
        ...menu,
        { name, price: parseFloat(price), course, image },
      ]);
      setName("");
      setPrice("");
      setCourse("");
      setImage("");
    }
  };

  const removeMenuItem = (index) => {
    const updatedMenu = [...menu];
    updatedMenu.splice(index, 1);
    setMenu(updatedMenu);
  };

  React.useEffect(() => {
    route.params.setMenu(menu);
  }, [menu]);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Manage Menu</Text>
      <TextInput
        style={styles.input}
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Price"
        keyboardType="numeric"
        value={price}
        onChangeText={setPrice}
      />
      <TextInput
        style={styles.input}
        placeholder="Course (e.g., Starter)"
        value={course}
        onChangeText={setCourse}
      />
      <TextInput
        style={styles.input}
        placeholder="Image URL"
        value={image}
        onChangeText={setImage}
      />
      <Button title="Add Item" onPress={addMenuItem} />
      <FlatList
        data={menu}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.listItem}>
            <Image source={{ uri: item.image }} style={styles.thumbnail} />
            <View style={{ flex: 1 }}>
              <Text>
                {item.course}: {item.name} - ${item.price}
              </Text>
            </View>
            <Button title="Remove" onPress={() => removeMenuItem(index)} />
          </View>
        )}
      />
    </View>
  );
};

const FilterMenuScreen = ({ route }) => {
  const [courseFilter, setCourseFilter] = useState("");
  const [filteredMenu, setFilteredMenu] = useState(route.params.menu);

  const filterMenu = () => {
    setFilteredMenu(
      route.params.menu.filter((item) =>
        item.course.toLowerCase().includes(courseFilter.toLowerCase())
      )
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Filter Menu</Text>
      <TextInput
        style={styles.input}
        placeholder="Course (e.g., Starter)"
        value={courseFilter}
        onChangeText={setCourseFilter}
      />
      <Button title="Filter" onPress={filterMenu} />
      <FlatList
        data={filteredMenu}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <Text style={styles.item}>
              {item.course}: {item.name} - ${item.price}
            </Text>
          </View>
        )}
      />
    </View>
  );
};

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ManageMenu" component={ManageMenuScreen} />
        <Stack.Screen name="FilterMenu" component={FilterMenuScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#fff",
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: "bold",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  item: {
    fontSize: 18,
    marginBottom: 10,
  },
  listItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  card: {
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 10,
    backgroundColor: "#f9f9f9",
  },
  image: {
    width: "100%",
    height: 150,
    borderRadius: 10,
    marginBottom: 10,
  },
  thumbnail: {
    width: 50,
    height: 50,
    marginRight: 10,
    borderRadius: 5,
  },
});